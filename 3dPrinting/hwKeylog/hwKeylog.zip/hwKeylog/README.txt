                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3274673
Teensy Hardware Keylogger by tmcdonagh is licensed under the GNU - GPL license.
http://creativecommons.org/licenses/GPL/2.0/

# Summary

Hardware keylogger that uses a [Teensy 3.6](https://www.pjrc.com/teensy/) to capture keystrokes, write them to a micro sd card, and send the keystrokes through the micro usb port on the Teensy. Keystrokes can either be read off sd card by taking it out or holding shift + password (default is 7980) to dump contents of text file out to the keyboard. Code can be found [here](https://github.com/tmcdonagh/HardwareKeylogger). Keyboard should be connected to female usb port and micro usb to male usb cable should be used to connect to computer. [Pinout information](https://www.pjrc.com/teensy/pinout.html).

# Print Settings

Printer Brand: FlashForge
Printer: Creator Pro
Rafts: No
Supports: Yes
Resolution: 0.1
Infill: 50%+
Filament_brand: Doesn't matter
Filament_color: Doesn't matter
Filament_material: PLA

Notes: 
Print both the case and lid vertical so the ridges don't allow the lid to slide out easily