                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2936677
Nintendo Switch Game Holder (Single Extruder) by tmcdonagh is licensed under the GNU - GPL license.
http://creativecommons.org/licenses/GPL/2.0/

# Summary

Nintendo Switch game holder that can be mounted on wall. Each piece connects with dovetail joints. Requires no glue as long as all screw holes are used and achors are used every 5-6 games. Command strips prove to be good replacements for screws if you can't drill into your wall. 

# Print Settings

Printer: Flash Forge Creator Pro
Rafts: Doesn't Matter
Supports: No
Resolution: 0.1 mm
Infill: 20% has translucent lines. Increase to eliminate lines.

Notes: 
Flip model in slicing program with screw holes facing down for best print quality.